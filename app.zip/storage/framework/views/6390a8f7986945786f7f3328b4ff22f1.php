

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Daftar Mahasiswa</h2>
    <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-primary">+ Tambah Mahasiswa</a>
</div>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success"><?php echo e($message); ?></div>
<?php endif; ?>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>NIM</th>
            <th>Jurusan</th>
            <th>Email</th>
            <th>No Hp</th>
            <th>IPK</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($m->id); ?></td>
            <td><?php echo e($m->nama); ?></td>
            <td><?php echo e($m->nim); ?></td>
            <td><?php echo e($m->jurusan); ?></td>
            <td><?php echo e($m->email); ?></td>
            <td><?php echo e($m->noHp); ?></td>
            <td><?php echo e($m->ipk); ?></td>
            <td>
                <a href="<?php echo e(route('mahasiswa.edit', $m->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('mahasiswa.destroy', $m->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus data ini?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">Belum ada data</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pbw-ti-24\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>