<?php $__env->startSection('title', 'Tambah Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    <h2 class="mb-4">Tambah Mahasiswa</h2>

    <form action="<?php echo e(route('insertdata')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" required>
        </div>

        <div class="mb-3">
            <label>NIM</label>
            <input type="number" class="form-control" name="nim" required>
        </div>

        <div class="mb-3">
            <label>Jurusan</label>
            <input type="text" class="form-control" name="jurusan" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="text" class="form-control" name="email" required>
        </div>

        <div class="mb-3">
            <label>NO HP</label>
            <input type="number" class="form-control" name="nohp" required>
        </div>

        <div class="mb-3">
            <label>IPK</label>
            <input type="text" class="form-control" name="ipk">
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pbw-ti-24\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>