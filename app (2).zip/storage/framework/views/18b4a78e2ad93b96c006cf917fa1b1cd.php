<?php $__env->startSection('content'); ?>
<h2>Edit Mahasiswa</h2>

<form action="<?php echo e(route('mahasiswa.update', $mahasiswa->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label class="form-label">Nama</label>
        <input type="text" name="nama" class="form-control" value="<?php echo e($mahasiswa->nama); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">NIM</label>
        <input type="text" name="nim" class="form-control" value="<?php echo e($mahasiswa->nim); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Jurusan</label>
        <input type="text" name="jurusan" class="form-control" value="<?php echo e($mahasiswa->jurusan); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="text" name="email" class="form-control" value="<?php echo e($mahasiswa->email); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">No HP</label>
        <input type="text" name="nohp" class="form-control" value="<?php echo e($mahasiswa->nohp); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">IPK</label>
        <input type="number" step="0.01" name="ipk" class="form-control" value="<?php echo e($mahasiswa->ipk); ?>">
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pbw-ti-24\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>