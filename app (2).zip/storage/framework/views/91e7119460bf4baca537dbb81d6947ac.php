<?php $__env->startSection('title', 'Tambah Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-3">
            <div class="card-header bg-white p-4 border-bottom-0">
                <h2 class="h4 mb-0 fw-bold">Tambah Mahasiswa Baru</h2>
                <p class="text-muted small mb-0">Silakan lengkapi formulir di bawah ini untuk menambahkan data.</p>
            </div>
            <div class="card-body p-4">
                <form action="<?php echo e(route('insertdata')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0 ps-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" value="<?php echo e(old('nama')); ?>" required placeholder="Nama lengkap mahasiswa">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">NIM</label>
                            <input type="number" class="form-control" name="nim" value="<?php echo e(old('nim')); ?>" required placeholder="Nomor Induk Mahasiswa">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small text-uppercase">Jurusan</label>
                            <input type="text" class="form-control" name="jurusan" value="<?php echo e(old('jurusan')); ?>" required placeholder="Program Studi / Jurusan">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required placeholder="mahasiswa@example.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">No. Handphone</label>
                            <input type="number" class="form-control" name="noHp" value="<?php echo e(old('noHp')); ?>" required placeholder="08xxxxxxxxxx">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">IPK</label>
                            <input type="number" step="0.01" min="0" max="4.00" class="form-control" name="ipk" value="<?php echo e(old('ipk')); ?>" placeholder="0.00">
                        </div>
                        
                        <div class="col-12 mt-4 d-flex justify-content-end gap-2">
                            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-light border">Batal</a>
                            <button type="submit" class="btn btn-primary px-4 fw-bold">Simpan Data</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pbw-ti-24\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>